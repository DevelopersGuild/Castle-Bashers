﻿// Copyright (c) 2015 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

using UnityEngine;
using Rewired;

namespace Rewired.Integration.UFPS {

    [AddComponentMenu("")]
    [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
    public class RewiredUFPSInputHelper : vp_Input {

        protected Rewired.Player player;

        protected override void Awake() {
            player = ReInput.players.GetPlayer(0);
            m_Instance = this;
        }

        // Override Methods

        // Override all input methods in the base class to get input from Rewired.

        public override bool DoGetButtonAny(string button) {
            return DoGetButton(button) || DoGetButtonDown(button) || DoGetButtonUp(button);
        }

        public override bool DoGetButton(string button) {
            return player.GetButton(button);
        }

        public override bool DoGetButtonDown(string button) {
            return player.GetButtonDown(button);
        }

        public override bool DoGetButtonUp(string button) {
            return player.GetButtonUp(button);
        }

        public override float DoGetAxisRaw(string axis) {
            return player.GetAxisRaw(axis);
        }

        // Override methods in the base class which no longer have any useful function.

        public override void SetDirty(bool dirty) { NotSupportedError("SetDirty"); }
        public override void SetupDefaults(string type = "") { NotSupportedError("SetupDefaults"); }
        public override void AddButton(string n, KeyCode k = KeyCode.None) { NotSupportedError("AddButton"); }
        public override void AddAxis(string n, KeyCode pk = KeyCode.None, KeyCode nk = KeyCode.None) { NotSupportedError("AddAxis"); }
        public override void AddUnityAxis(string n) { NotSupportedError("AddUnityAxis"); }
        public override void UpdateDictionaries() { NotSupportedError("UpdateDictionaries"); }

        // Private Methods

        private void NotSupportedError(string name) {
            Debug.LogError("The method \"" + name + "\" is not supported. Use Rewired to manage input and reassignment instead.");
        }
    }
}