﻿// Copyright (c) 2015 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

using UnityEditor;

namespace Rewired.Integration.UFPS.Editor {

    [CustomEditor(typeof(RewiredUFPSInputHelper))]
    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
    public sealed class RewiredUFPSInputHelperInspector : UnityEditor.Editor {

        public override void OnInspectorGUI() {
        }
    }
}